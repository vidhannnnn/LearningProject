from django.shortcuts import render , redirect
from courses.models import Course , Video , UserCourse, Notes
from django.shortcuts import HttpResponse
# Create your views here.
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView
from django.utils.decorators import method_decorator


def notePage(request):
    course = Notes.objects.get()
    
    return  render(request , template_name="courses/notes.html" )  