from courses.views.homepage import HomePageView
from courses.views.courses import coursePage , MyCoursesList
from courses.views.auth import SignupView , LoginView , signout
from courses.views.checkout import checkout , verifyPayment
from courses.views.notes import notePage
